##  JANGAN LUPA KLIK LINK DIBAWAH INI⚠️⬇️

 https://youtube.com/channel/UCqK3KOcJI1dmbyuiTIzlKIA?sub_confirmation=1

+ RDP Windows Gratis 6 Jam

+ Buat RDP Windows 10 Ram 7GB 2 Core Cpu Dengan Github:

+ Tekan Tombol Fork untuk membuat RDP (Bagi Pengguna Android/HP Disilahkan Pake Mode Desktop).

+ Kunjungi https://remotedesktop.google.com/u/4/headless

+ Tekan Mulai>Berikutnya>Izinkan

+ Di sebelah kanan Tulisan Windows (PowerShell) Ada Ikon Salin,Klik Aja

+ Kembali Ke github

+ Pergi Ke Action <Klik Select workflow< Pilih Har Pito,Pencet Run workflow

+ Paste Cmd Dari Remote desktop Chrome nya
 
+ Masukin Pin Minimal 6 digit, Lalu Tekan Run workflow

+ Refresh Web/halaman dan masuk ke Har Pito> klik build

+ *Tunggu 1-5 menit*

+ Kunjungi Link Ini https://remotedesktop.google.com/u/4/access

+ Klik Logo Berbentuk Komputer

+ Masukin Pin Yg sudah kalian buat tadi

+ Tekan Ikon Panah ➜ Berwarna Biru

+ Dan Rdp Pun Siap Digunakan
