$i = 36000
do {
    Write-Host $i
    Sleep 60000
    $i--
} while ($i -gt 0)
